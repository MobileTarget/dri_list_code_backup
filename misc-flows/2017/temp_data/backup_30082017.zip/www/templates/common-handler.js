$scope.process_handler = function(params) {
	console.log("processed common handler", params);
}