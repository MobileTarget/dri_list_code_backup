#!/bin/bash
npm install angular@$VERSION angular-mocks@$VERSION
